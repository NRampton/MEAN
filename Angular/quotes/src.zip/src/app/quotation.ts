export class Quotation {
  public content: string = "";
  public source: string = "";
  public score: number = 0;
}
