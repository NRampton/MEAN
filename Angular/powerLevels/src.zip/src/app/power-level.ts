export class PowerLevel {
  public powerLevel: number = 1;
}
